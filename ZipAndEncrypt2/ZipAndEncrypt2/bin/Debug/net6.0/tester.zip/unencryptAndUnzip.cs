// unencrypt and Zip

// C# program to print Hello World!
using System;

// namespace declaration
namespace HelloWorldApp
{

    // Class declaration
    class Geeks
    {

        // Main Method
        static void Main(string[] args)
        {

            // statement
            // printing Hello World!
            Console.WriteLine("Hello World!");

            // To prevents the screen from 
            // running and closing quickly
            Console.ReadKey();
        }
    }
}